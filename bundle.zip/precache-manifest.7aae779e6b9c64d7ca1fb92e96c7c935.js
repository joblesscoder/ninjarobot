self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c0159b10b748fafb80b257b67e4da1d1",
    "url": "/ninjarobot/index.html"
  },
  {
    "revision": "bbfabdfe614ecd6659ea",
    "url": "/ninjarobot/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "575cc7f83a048be6e0bc",
    "url": "/ninjarobot/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "bbfabdfe614ecd6659ea",
    "url": "/ninjarobot/static/js/2.22669be9.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/ninjarobot/static/js/2.22669be9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "575cc7f83a048be6e0bc",
    "url": "/ninjarobot/static/js/main.ee8e5898.chunk.js"
  },
  {
    "revision": "ec86bc820098ea8f0962",
    "url": "/ninjarobot/static/js/runtime-main.1e322108.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/ninjarobot/static/media/persik.4e1ec840.png"
  }
]);