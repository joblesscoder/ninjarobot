self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2e9de0a7c3883a79791d09a799d9d642",
    "url": "/ninjarobot/index.html"
  },
  {
    "revision": "9d5019174731e5c567ac",
    "url": "/ninjarobot/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "0f566a38556a77dd98d1",
    "url": "/ninjarobot/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "9d5019174731e5c567ac",
    "url": "/ninjarobot/static/js/2.283985be.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/ninjarobot/static/js/2.283985be.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0f566a38556a77dd98d1",
    "url": "/ninjarobot/static/js/main.b0b62f6e.chunk.js"
  },
  {
    "revision": "ec86bc820098ea8f0962",
    "url": "/ninjarobot/static/js/runtime-main.1e322108.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/ninjarobot/static/media/persik.4e1ec840.png"
  }
]);