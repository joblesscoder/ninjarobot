self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "aebbea71ece743a3eac183024de60c88",
    "url": "/index.html"
  },
  {
    "revision": "038911a9aa267136cb30",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "a5cb49c6667ffec5c031",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "038911a9aa267136cb30",
    "url": "/static/js/2.ff62559f.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.ff62559f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a5cb49c6667ffec5c031",
    "url": "/static/js/main.7dc76119.chunk.js"
  },
  {
    "revision": "746d57ce13775dde22e6",
    "url": "/static/js/runtime-main.87a4bd80.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);